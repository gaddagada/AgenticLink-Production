#!/usr/bin/env bash
set -euo pipefail
BASE=${BASE:-http://localhost:8080}
echo "Create URL:"; curl -s -X POST "$BASE/api/urls" -H 'Content-Type: application/json' -d '{"url":"https://example.com","ttlHours":24}'; echo
echo "Start governed SDLC workflow:"; curl -s -X POST "$BASE/api/orchestrations" -H 'Content-Type: application/json' -d '{"requirement":"Build URL shortener with analytics and reliability controls"}'; echo
echo "Use returned id to approve security-review, then release."
