# Architecture

## Business plane
`UrlController -> UrlShortenerService -> JPA repositories -> H2`

The URL service creates, resolves, expires/deactivates and measures short links. URL validation blocks local/private destinations to reduce SSRF exposure.

## Agentic control plane
`OrchestrationController/ScenarioController -> AgenticOrchestrator -> EngineeringAgent registry`

Dependency graph:

`understand -> design -> security-review(approval) -> implement -> [test || docs] -> release(approval)`

The graph has explicit dependencies and synchronization. A stage executes only when all dependencies have succeeded (normally or through an approved fallback). High-impact stages require human approval before the agent executes.

## Governance and recovery
- Ambiguous input pauses at a clarification gate.
- Security agent enforces security/compliance/change-control rules.
- Each execution captures a context checkpoint.
- Failures use bounded retry budgets.
- Selected stages have fallback agents.
- Unrecoverable failure restores the checkpoint and safe-stops.
- Replanning invalidates downstream artifacts and approvals.
- Audit events record starts, decisions, approvals, retries, fallback, rollback, replanning and completion.

## Metrics
The orchestrator calculates run count, success rate, retry count, fallback count, rollback count, mean time to recovery and average end-to-end latency from actual workflow state.

## Production evolution
For a real distributed deployment, replace in-memory workflow state with a durable workflow/event store, H2 with PostgreSQL, and deterministic agents with authenticated LLM/tool adapters. Add distributed locking/idempotency, OpenTelemetry export, secrets management and organization-specific policy-as-code.
