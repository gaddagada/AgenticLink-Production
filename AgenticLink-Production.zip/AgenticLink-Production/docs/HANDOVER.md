# Team handover

1. Install JDK 8 and Maven 3.6+.
2. Run `mvn clean test`.
3. Run `mvn clean package`.
4. Start `java -jar target/agenticlink-1.0.0.jar`.
5. Verify `/actuator/health` returns `UP`.
6. Demonstrate URL creation/redirect/analytics.
7. Demonstrate `/api/scenarios/greenfield`, approve security-review, then approve release.
8. Demonstrate ambiguous clarification, fallback recovery and rollback/safe-stop scenarios.
9. Show `/api/orchestrations/graph` and `/api/orchestrations/metrics` to explain governance and reliability evidence.

The project targets Java 8 source compatibility through Spring Boot 2.7.18. No Java 9+ collection factories, records, `var`, pattern matching, `Stream.toList()` or no-argument `Optional.orElseThrow()` are used.
