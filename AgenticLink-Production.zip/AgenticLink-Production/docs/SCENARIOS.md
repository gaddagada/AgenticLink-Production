# Executable scenarios

## Greenfield
`POST /api/scenarios/greenfield`

Creates a new URL-shortener requirement and executes requirement understanding and architecture, then pauses at the governed security/change-control approval gate. After approval, implementation runs; testing and documentation become parallel-ready branches and synchronize before the final release approval.

## Brownfield
`POST /api/scenarios/brownfield`

Models an enhancement to the existing service. The requirement explicitly asks the architecture/implementation stages to identify impacted API, service, persistence and tests before the governed change proceeds.

## Ambiguous
`POST /api/scenarios/ambiguous`

Starts with `Make it better`. The orchestrator detects insufficient specificity and enters `WAITING_CLARIFICATION`, emitting clarification questions. `POST /api/orchestrations/{id}/clarify` supplies the human decision and resumes execution.

## Fallback
`POST /api/scenarios/fallback`

Uses a deterministic failure token to demonstrate bounded retries. After retry exhaustion the testing stage invokes its fallback agent, records `FALLBACK_SUCCESS`, and continues without bypassing later approval gates.

## Rollback / safe-stop
`POST /api/scenarios/rollback`

The security/compliance policy agent rejects a prohibited request. After the bounded retry budget is exhausted, the orchestrator restores the pre-stage context checkpoint, records `ROLLBACK`, and safe-stops for human intervention.
