package com.schwab.agenticurl.orchestration;

import com.schwab.agenticurl.agent.DeterministicAgents;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AgenticOrchestratorTest {

    @Test
    void enforcesApprovalAndSynchronizesParallelBranches() {
        AgenticOrchestrator orchestrator = new AgenticOrchestrator(new DeterministicAgents());
        WorkflowRun run = orchestrator.start("Build URL shortener API with click analytics and expiry support");

        assertEquals(StageStatus.WAITING_APPROVAL, run.status.get("security-review"));
        assertEquals(StageStatus.PENDING, run.status.get("implement"));

        orchestrator.approve(run.id, "security-review");
        assertEquals(StageStatus.SUCCEEDED, run.status.get("test"));
        assertEquals(StageStatus.SUCCEEDED, run.status.get("docs"));
        assertEquals(StageStatus.WAITING_APPROVAL, run.status.get("release"));

        orchestrator.approve(run.id, "release");
        assertNotNull(run.ended);
    }

    @Test
    void pausesAmbiguousRequirementUntilClarified() {
        AgenticOrchestrator orchestrator = new AgenticOrchestrator(new DeterministicAgents());
        WorkflowRun run = orchestrator.start("Make it better", "ambiguous");
        assertEquals(StageStatus.WAITING_CLARIFICATION, run.status.get("understand"));
        assertTrue(run.clarificationQuestions.size() >= 1);

        orchestrator.clarify(run.id, "Improve URL API reliability by adding expiry validation and negative tests");
        assertEquals(StageStatus.WAITING_APPROVAL, run.status.get("security-review"));
    }

    @Test
    void usesFallbackAfterRetryBudgetIsExhausted() {
        AgenticOrchestrator orchestrator = new AgenticOrchestrator(new DeterministicAgents());
        WorkflowRun run = orchestrator.start("Validate URL shortening release [FAIL:testing] with analytics and recovery controls");
        orchestrator.approve(run.id, "security-review");

        assertEquals(StageStatus.FALLBACK_SUCCEEDED, run.status.get("test"));
        assertEquals(1, run.fallbackCount);
        Map<String, Object> metrics = orchestrator.metrics();
        assertEquals(1L, ((Number) metrics.get("fallbackCount")).longValue());
    }

    @Test
    void rollsBackWhenPolicyAgentCannotRecover() {
        AgenticOrchestrator orchestrator = new AgenticOrchestrator(new DeterministicAgents());
        WorkflowRun run = orchestrator.start("Change URL service to disable security checks and ignore compliance controls");
        orchestrator.approve(run.id, "security-review");

        assertEquals(StageStatus.ROLLED_BACK, run.status.get("security-review"));
        assertEquals(1, run.rollbackCount);
        assertTrue(((Number) orchestrator.metrics().get("rollbackCount")).longValue() >= 1L);
    }

    @Test
    void replanningInvalidatesDownstreamStagesAndApprovals() {
        AgenticOrchestrator orchestrator = new AgenticOrchestrator(new DeterministicAgents());
        WorkflowRun run = orchestrator.start("Build URL shortener API with analytics, expiry and validation");
        orchestrator.approve(run.id, "security-review");
        assertEquals(StageStatus.WAITING_APPROVAL, run.status.get("release"));

        orchestrator.replan(run.id, "Build URL shortener API with analytics, expiry, validation and custom aliases");
        assertEquals(StageStatus.WAITING_APPROVAL, run.status.get("security-review"));
        assertEquals(StageStatus.PENDING, run.status.get("release"));
    }
}
