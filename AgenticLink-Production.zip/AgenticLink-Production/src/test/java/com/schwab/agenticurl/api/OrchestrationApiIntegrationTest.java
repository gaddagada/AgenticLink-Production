package com.schwab.agenticurl.api;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class OrchestrationApiIntegrationTest {
    @Autowired
    private MockMvc mvc;

    @Test
    void exposesDependencyGraphAndAmbiguityGate() throws Exception {
        mvc.perform(get("/api/orchestrations/graph"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.entryGate").value("understand"))
                .andExpect(jsonPath("$.exitGate").value("release"));

        mvc.perform(post("/api/scenarios/ambiguous"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status.understand").value("WAITING_CLARIFICATION"));
    }
}
