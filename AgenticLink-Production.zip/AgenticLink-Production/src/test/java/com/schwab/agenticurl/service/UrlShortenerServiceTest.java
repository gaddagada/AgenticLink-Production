package com.schwab.agenticurl.service;
import com.schwab.agenticurl.repo.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*; class UrlShortenerServiceTest {
    @Test void blocksLocalhost(){UrlShortenerService s=new UrlShortenerService(mock(ShortUrlRepository.class),mock(ClickEventRepository.class));assertThrows(IllegalArgumentException.class,()->s.create("http://localhost/admin",null)); } }
