package com.schwab.agenticurl.agent;

import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@Component
public class DeterministicAgents {
    private final Map<String, EngineeringAgent> agents = new HashMap<String, EngineeringAgent>();

    public DeterministicAgents() {
        register("requirements", "Normalize intent, assumptions and acceptance criteria");
        register("architecture", "Produce component, API, persistence and data-flow decisions");
        registerPolicyAgent();
        register("implementation", "Produce a bounded implementation change-set and impacted-module plan");
        register("testing", "Produce unit, integration, negative and recovery test evidence");
        register("documentation", "Produce setup, API, operations and decision documentation");
        register("release", "Evaluate release-readiness evidence and unresolved risks");
        register("fallback-testing", "Run reduced deterministic validation when the primary test agent fails");
        register("fallback-implementation", "Produce a minimal-risk implementation plan when the primary implementation agent fails");
    }

    private void register(final String name, final String purpose) {
        agents.put(name, new EngineeringAgent() {
            @Override
            public String name() { return name; }

            @Override
            public AgentResult execute(String requirement, Map<String, Object> context) {
                if (shouldFail(requirement, name)) {
                    return new AgentResult(false, new LinkedHashMap<String, Object>(),
                            "Failure injected for recovery-path demonstration: " + name);
                }
                return new AgentResult(true, artifact(name, purpose, requirement),
                        "Deterministic agent completed within bounded autonomy");
            }
        });
    }

    private void registerPolicyAgent() {
        agents.put("security", new EngineeringAgent() {
            @Override
            public String name() { return "security"; }

            @Override
            public AgentResult execute(String requirement, Map<String, Object> context) {
                String normalized = requirement == null ? "" : requirement.toLowerCase(Locale.ENGLISH);
                List<String> prohibited = Arrays.asList("disable security", "bypass approval", "skip tests", "ignore compliance");
                for (String phrase : prohibited) {
                    if (normalized.contains(phrase)) {
                        return new AgentResult(false, new LinkedHashMap<String, Object>(),
                                "Policy guardrail rejected prohibited change: " + phrase);
                    }
                }
                Map<String, Object> out = artifact("security", "Security/compliance/change-control policy evidence", requirement);
                out.put("securityValidated", true);
                out.put("complianceValidated", true);
                out.put("changeControlRequired", true);
                return new AgentResult(true, out, "Security, compliance and change-control guardrails passed");
            }
        });
    }

    private boolean shouldFail(String requirement, String agent) {
        if (requirement == null) return false;
        String token = "[fail:" + agent + "]";
        return requirement.toLowerCase(Locale.ENGLISH).contains(token);
    }

    private Map<String, Object> artifact(String name, String purpose, String requirement) {
        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("agent", name);
        result.put("artifact", purpose);
        result.put("requirement", requirement);
        result.put("decision", "ACCEPT");
        return result;
    }

    public EngineeringAgent get(String name) {
        return Optional.ofNullable(agents.get(name))
                .orElseThrow(() -> new IllegalArgumentException("Engineering agent not found: " + name));
    }
}
