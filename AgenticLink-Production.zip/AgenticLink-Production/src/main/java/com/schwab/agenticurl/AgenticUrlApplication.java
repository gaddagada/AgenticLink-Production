package com.schwab.agenticurl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenticUrlApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgenticUrlApplication.class, args);
    }
}
