package com.schwab.agenticurl.api;

import com.schwab.agenticurl.orchestration.AgenticOrchestrator;
import com.schwab.agenticurl.orchestration.WorkflowRun;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/orchestrations")
public class OrchestrationController {
    private final AgenticOrchestrator orchestrator;

    public OrchestrationController(AgenticOrchestrator orchestrator) {
        this.orchestrator = orchestrator;
    }

    public static class RequirementRequest {
        public String requirement;
    }

    @PostMapping
    public WorkflowRun start(@RequestBody RequirementRequest request) {
        return orchestrator.start(request.requirement);
    }

    @GetMapping("/{id}")
    public WorkflowRun get(@PathVariable String id) {
        return orchestrator.get(id);
    }

    @PostMapping("/{id}/approve/{stage}")
    public WorkflowRun approve(@PathVariable String id, @PathVariable String stage) {
        return orchestrator.approve(id, stage);
    }

    @PostMapping("/{id}/clarify")
    public WorkflowRun clarify(@PathVariable String id, @RequestBody RequirementRequest request) {
        return orchestrator.clarify(id, request.requirement);
    }

    @PostMapping("/{id}/replan")
    public WorkflowRun replan(@PathVariable String id, @RequestBody RequirementRequest request) {
        return orchestrator.replan(id, request.requirement);
    }

    @GetMapping("/metrics")
    public Map<String, Object> metrics() {
        return orchestrator.metrics();
    }

    @GetMapping("/graph")
    public Map<String, Object> graph() {
        return orchestrator.graph();
    }
}
