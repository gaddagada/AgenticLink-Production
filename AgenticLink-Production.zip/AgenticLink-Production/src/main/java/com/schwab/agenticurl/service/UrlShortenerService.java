package com.schwab.agenticurl.service;

import com.schwab.agenticurl.domain.ClickEvent;
import com.schwab.agenticurl.domain.ShortUrl;
import com.schwab.agenticurl.repo.ClickEventRepository;
import com.schwab.agenticurl.repo.ShortUrlRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.InetAddress;
import java.net.URI;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.UUID;

@Service
public class UrlShortenerService {
    private final ShortUrlRepository urls;
    private final ClickEventRepository clicks;

    public UrlShortenerService(ShortUrlRepository urls, ClickEventRepository clicks) {
        this.urls = urls;
        this.clicks = clicks;
    }

    @Transactional
    public ShortUrl create(String target, Integer ttlHours) {
        validate(target);
        String code;
        do {
            code = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        } while (urls.existsById(code));

        Instant expiresAt = ttlHours == null ? null : Instant.now().plus(ttlHours, ChronoUnit.HOURS);
        return urls.save(new ShortUrl(code, target, expiresAt));
    }

    @Transactional
    public String resolve(String code, String userAgent) {
        ShortUrl shortUrl = urls.findById(code)
                .orElseThrow(() -> new NoSuchElementException("Short URL not found"));
        if (!shortUrl.isActive() || (shortUrl.getExpiresAt() != null && shortUrl.getExpiresAt().isBefore(Instant.now()))) {
            throw new IllegalStateException("Short URL inactive or expired");
        }
        clicks.save(new ClickEvent(code, userAgent));
        return shortUrl.getTargetUrl();
    }

    public long clicks(String code) {
        if (!urls.existsById(code)) throw new NoSuchElementException("Short URL not found");
        return clicks.countByCode(code);
    }

    @Transactional
    public void deactivate(String code) {
        ShortUrl shortUrl = urls.findById(code)
                .orElseThrow(() -> new NoSuchElementException("Short URL not found"));
        shortUrl.deactivate();
    }

    private void validate(String raw) {
        try {
            URI uri = URI.create(raw);
            if (!Arrays.asList("http", "https").contains(uri.getScheme()) || uri.getHost() == null) {
                throw new IllegalArgumentException("Only absolute http/https URLs are allowed");
            }
            InetAddress address = InetAddress.getByName(uri.getHost());
            if (address.isAnyLocalAddress() || address.isLoopbackAddress() || address.isLinkLocalAddress()
                    || address.isSiteLocalAddress() || address.isMulticastAddress()) {
                throw new IllegalArgumentException("Local/private network targets are blocked");
            }
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid or unresolvable URL", e);
        }
    }
}
