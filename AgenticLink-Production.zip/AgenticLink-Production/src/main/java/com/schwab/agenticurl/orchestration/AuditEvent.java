package com.schwab.agenticurl.orchestration;

import java.time.Instant;

public class AuditEvent {
    private final Instant at;
    private final String workflowId;
    private final String stage;
    private final String action;
    private final String detail;

    public AuditEvent(Instant at, String workflowId, String stage, String action, String detail) {
        this.at = at;
        this.workflowId = workflowId;
        this.stage = stage;
        this.action = action;
        this.detail = detail;
    }

    public Instant getAt() { return at; }
    public String getWorkflowId() { return workflowId; }
    public String getStage() { return stage; }
    public String getAction() { return action; }
    public String getDetail() { return detail; }
}
