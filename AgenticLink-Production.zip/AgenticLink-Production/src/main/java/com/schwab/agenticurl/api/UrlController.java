package com.schwab.agenticurl.api;

import com.schwab.agenticurl.domain.ShortUrl;
import com.schwab.agenticurl.service.UrlShortenerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.net.URI;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class UrlController {
    private final UrlShortenerService service;

    public UrlController(UrlShortenerService service) {
        this.service = service;
    }

    public static class CreateRequest {
        @NotBlank
        public String url;
        @Min(1) @Max(8760)
        public Integer ttlHours;
    }

    @PostMapping("/api/urls")
    public ResponseEntity<?> create(@Valid @RequestBody CreateRequest request) {
        ShortUrl shortUrl = service.create(request.url, request.ttlHours);
        Map<String, Object> body = new LinkedHashMap<String, Object>();
        body.put("code", shortUrl.getCode());
        body.put("shortUrl", "http://localhost:8080/" + shortUrl.getCode());
        body.put("targetUrl", shortUrl.getTargetUrl());
        body.put("expiresAt", shortUrl.getExpiresAt());
        return ResponseEntity.status(201).body(body);
    }

    @GetMapping("/{code}")
    public ResponseEntity<Void> redirect(@PathVariable String code, HttpServletRequest request) {
        return ResponseEntity.status(302)
                .location(URI.create(service.resolve(code, request.getHeader("User-Agent"))))
                .build();
    }

    @GetMapping("/api/urls/{code}/analytics")
    public Map<String, Object> analytics(@PathVariable String code) {
        Map<String, Object> body = new LinkedHashMap<String, Object>();
        body.put("code", code);
        body.put("clicks", service.clicks(code));
        return body;
    }

    @DeleteMapping("/api/urls/{code}")
    public ResponseEntity<Void> deactivate(@PathVariable String code) {
        service.deactivate(code);
        return ResponseEntity.noContent().build();
    }

    @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class, java.util.NoSuchElementException.class})
    public ResponseEntity<?> handle(RuntimeException error) {
        return ResponseEntity.badRequest().body(Collections.singletonMap("error", error.getMessage()));
    }
}
