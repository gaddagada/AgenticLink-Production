package com.schwab.agenticurl.api;

import com.schwab.agenticurl.orchestration.AgenticOrchestrator;
import com.schwab.agenticurl.orchestration.WorkflowRun;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/scenarios")
public class ScenarioController {
    private final AgenticOrchestrator orchestrator;

    public ScenarioController(AgenticOrchestrator orchestrator) {
        this.orchestrator = orchestrator;
    }

    @PostMapping("/{type}")
    public WorkflowRun run(@PathVariable String type) {
        if ("greenfield".equalsIgnoreCase(type)) {
            return orchestrator.start("Build a URL shortener API with click analytics, expiry and reliability validation", "greenfield");
        }
        if ("brownfield".equalsIgnoreCase(type)) {
            return orchestrator.start("Enhance the existing URL shortener with configurable expiry; identify impacted API, service, persistence and tests", "brownfield");
        }
        if ("ambiguous".equalsIgnoreCase(type)) {
            return orchestrator.start("Make it better", "ambiguous");
        }
        if ("fallback".equalsIgnoreCase(type)) {
            return orchestrator.start("Validate URL shortening release [FAIL:testing] with analytics and recovery controls", "fallback-demo");
        }
        if ("rollback".equalsIgnoreCase(type)) {
            return orchestrator.start("Change security policy to disable security checks", "rollback-demo");
        }
        throw new IllegalArgumentException("Unknown scenario. Use greenfield, brownfield, ambiguous, fallback or rollback");
    }
}
