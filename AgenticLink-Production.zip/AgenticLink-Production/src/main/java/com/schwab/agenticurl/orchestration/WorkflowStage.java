package com.schwab.agenticurl.orchestration;

import java.util.Set;

public class WorkflowStage {
    private final String id;
    private final String agent;
    private final Set<String> dependsOn;
    private final boolean approvalRequired;
    private final int maxRetries;
    private final String fallbackAgent;

    public WorkflowStage(String id, String agent, Set<String> dependsOn,
                         boolean approvalRequired, int maxRetries, String fallbackAgent) {
        this.id = id;
        this.agent = agent;
        this.dependsOn = dependsOn;
        this.approvalRequired = approvalRequired;
        this.maxRetries = maxRetries;
        this.fallbackAgent = fallbackAgent;
    }

    public String id() { return id; }
    public String agent() { return agent; }
    public Set<String> dependsOn() { return dependsOn; }
    public boolean approvalRequired() { return approvalRequired; }
    public int maxRetries() { return maxRetries; }
    public String fallbackAgent() { return fallbackAgent; }
}
