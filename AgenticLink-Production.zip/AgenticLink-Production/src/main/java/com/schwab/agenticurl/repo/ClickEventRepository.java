package com.schwab.agenticurl.repo;
import com.schwab.agenticurl.domain.ClickEvent;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ClickEventRepository extends JpaRepository<ClickEvent,Long>{ long countByCode(String code); }
