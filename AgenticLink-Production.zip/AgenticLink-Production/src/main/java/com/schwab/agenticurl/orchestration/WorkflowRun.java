package com.schwab.agenticurl.orchestration;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class WorkflowRun {
    public final String id = UUID.randomUUID().toString();
    public final String originalRequirement;
    public volatile String activeRequirement;
    public final String scenario;
    public final Instant started = Instant.now();
    public volatile Instant ended;
    public volatile Instant firstFailureAt;
    public volatile Instant recoveredAt;
    public final Map<String, StageStatus> status = new ConcurrentHashMap<String, StageStatus>();
    public final Map<String, Object> context = new ConcurrentHashMap<String, Object>();
    public final Map<String, Map<String, Object>> checkpoints = new ConcurrentHashMap<String, Map<String, Object>>();
    public final List<AuditEvent> audit = Collections.synchronizedList(new ArrayList<AuditEvent>());
    public final Map<String, Integer> retries = new ConcurrentHashMap<String, Integer>();
    public final Map<String, Integer> artifactVersions = new ConcurrentHashMap<String, Integer>();
    public final Set<String> approvals = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    public final List<String> clarificationQuestions = Collections.synchronizedList(new ArrayList<String>());
    public volatile int rollbackCount;
    public volatile int fallbackCount;

    public WorkflowRun(String requirement, String scenario) {
        this.originalRequirement = requirement;
        this.activeRequirement = requirement;
        this.scenario = scenario;
    }

    public String getId() { return id; }
    public String getOriginalRequirement() { return originalRequirement; }
    public String getActiveRequirement() { return activeRequirement; }
    public String getScenario() { return scenario; }
    public Instant getStarted() { return started; }
    public Instant getEnded() { return ended; }
    public Map<String, StageStatus> getStatus() { return status; }
    public Map<String, Object> getContext() { return context; }
    public List<AuditEvent> getAudit() { return audit; }
    public Map<String, Integer> getRetries() { return retries; }
    public Map<String, Integer> getArtifactVersions() { return artifactVersions; }
    public Set<String> getApprovals() { return approvals; }
    public List<String> getClarificationQuestions() { return clarificationQuestions; }
    public int getRollbackCount() { return rollbackCount; }
    public int getFallbackCount() { return fallbackCount; }
}
