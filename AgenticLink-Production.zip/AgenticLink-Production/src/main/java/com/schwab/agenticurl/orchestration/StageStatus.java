package com.schwab.agenticurl.orchestration;

public enum StageStatus {
    PENDING,
    RUNNING,
    WAITING_APPROVAL,
    WAITING_CLARIFICATION,
    SUCCEEDED,
    FALLBACK_SUCCEEDED,
    FAILED,
    ROLLED_BACK,
    SAFE_STOPPED
}
