package com.schwab.agenticurl.repo;
import com.schwab.agenticurl.domain.ShortUrl;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ShortUrlRepository extends JpaRepository<ShortUrl,String>{}
