package com.schwab.agenticurl.agent;

import java.util.Map;

public interface EngineeringAgent {
    String name();

    AgentResult execute(String requirement, Map<String, Object> context);

    final class AgentResult {
        private final boolean success;
        private final Map<String, Object> output;
        private final String rationale;

        public AgentResult(boolean success, Map<String, Object> output, String rationale) {
            this.success = success;
            this.output = output;
            this.rationale = rationale;
        }

        public boolean success() { return success; }
        public Map<String, Object> output() { return output; }
        public String rationale() { return rationale; }
    }
}
