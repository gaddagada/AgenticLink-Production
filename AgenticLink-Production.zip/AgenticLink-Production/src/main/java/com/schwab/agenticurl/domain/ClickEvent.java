package com.schwab.agenticurl.domain;
import javax.persistence.*;
import java.time.Instant;
@Entity public class ClickEvent {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String code;
    private Instant clickedAt;
    private String userAgent;
    protected ClickEvent(){}

    public ClickEvent(String c,String ua){code=c;userAgent=ua;clickedAt=Instant.now(); }

    public String getCode(){return code; }

    public Instant getClickedAt(){return clickedAt; } }
