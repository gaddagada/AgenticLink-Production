package com.schwab.agenticurl.orchestration;

import com.schwab.agenticurl.agent.DeterministicAgents;
import com.schwab.agenticurl.agent.EngineeringAgent;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class AgenticOrchestrator {
    private final DeterministicAgents agents;
    private final Map<String, WorkflowRun> runs = new ConcurrentHashMap<String, WorkflowRun>();

    private final List<WorkflowStage> graph = Arrays.asList(
            new WorkflowStage("understand", "requirements", Collections.<String>emptySet(), false, 1, null),
            new WorkflowStage("design", "architecture", set("understand"), false, 1, null),
            new WorkflowStage("security-review", "security", set("design"), true, 1, null),
            new WorkflowStage("implement", "implementation", set("design", "security-review"), false, 2, "fallback-implementation"),
            new WorkflowStage("test", "testing", set("implement"), false, 2, "fallback-testing"),
            new WorkflowStage("docs", "documentation", set("implement"), false, 1, null),
            new WorkflowStage("release", "release", set("test", "docs"), true, 1, null)
    );

    public AgenticOrchestrator(DeterministicAgents agents) {
        this.agents = agents;
    }

    private static Set<String> set(String... values) {
        return new HashSet<String>(Arrays.asList(values));
    }

    public WorkflowRun start(String requirement) {
        return start(requirement, "custom");
    }

    public synchronized WorkflowRun start(String requirement, String scenario) {
        if (requirement == null || requirement.trim().isEmpty()) {
            throw new IllegalArgumentException("requirement is required");
        }
        WorkflowRun run = new WorkflowRun(requirement.trim(), scenario);
        for (WorkflowStage stage : graph) {
            run.status.put(stage.id(), StageStatus.PENDING);
        }
        runs.put(run.id, run);
        audit(run, "workflow", "CREATED", "Scenario=" + scenario + "; dependency graph initialized");

        if (isAmbiguous(requirement)) {
            run.status.put("understand", StageStatus.WAITING_CLARIFICATION);
            run.clarificationQuestions.add("What measurable outcome defines success?");
            run.clarificationQuestions.add("Which security/reliability constraints are mandatory?");
            audit(run, "understand", "AMBIGUITY_DETECTED", "Execution paused pending human clarification");
            return run;
        }
        advance(run);
        return run;
    }

    public WorkflowRun get(String id) {
        WorkflowRun run = runs.get(id);
        if (run == null) throw new NoSuchElementException("Workflow not found: " + id);
        return run;
    }

    public synchronized WorkflowRun clarify(String id, String clarifiedRequirement) {
        WorkflowRun run = get(id);
        if (run.status.get("understand") != StageStatus.WAITING_CLARIFICATION) {
            throw new IllegalStateException("Workflow is not awaiting clarification");
        }
        if (clarifiedRequirement == null || clarifiedRequirement.trim().isEmpty()) {
            throw new IllegalArgumentException("clarifiedRequirement is required");
        }
        run.activeRequirement = clarifiedRequirement.trim();
        run.context.put("clarification", clarifiedRequirement.trim());
        run.status.put("understand", StageStatus.PENDING);
        audit(run, "understand", "HUMAN_CLARIFICATION", "Requirement clarified; controlled execution resumed");
        advance(run);
        return run;
    }

    public synchronized WorkflowRun approve(String id, String stageId) {
        WorkflowRun run = get(id);
        if (run.status.get(stageId) != StageStatus.WAITING_APPROVAL) {
            throw new IllegalStateException("Stage is not awaiting approval: " + stageId);
        }
        run.approvals.add(stageId);
        run.status.put(stageId, StageStatus.PENDING);
        audit(run, stageId, "HUMAN_APPROVED", "Approval checkpoint passed; stage may now execute");
        advance(run);
        return run;
    }

    public synchronized WorkflowRun replan(String id, String changedRequirement) {
        WorkflowRun run = get(id);
        if (changedRequirement == null || changedRequirement.trim().isEmpty()) {
            throw new IllegalArgumentException("changedRequirement is required");
        }
        run.activeRequirement = changedRequirement.trim();
        run.context.put("replannedRequirement", changedRequirement.trim());
        boolean invalidate = false;
        for (WorkflowStage stage : graph) {
            if (stage.id().equals("design")) invalidate = true;
            if (invalidate) {
                run.status.put(stage.id(), StageStatus.PENDING);
                run.approvals.remove(stage.id());
                run.context.remove(stage.id());
            }
        }
        run.ended = null;
        audit(run, "workflow", "REPLAN", "Upstream requirement changed; downstream artifacts and approvals invalidated");
        advance(run);
        return run;
    }

    public Map<String, Object> graph() {
        List<Map<String, Object>> nodes = new ArrayList<Map<String, Object>>();
        for (WorkflowStage stage : graph) {
            Map<String, Object> node = new LinkedHashMap<String, Object>();
            node.put("id", stage.id());
            node.put("agent", stage.agent());
            node.put("dependsOn", stage.dependsOn());
            node.put("approvalRequired", stage.approvalRequired());
            node.put("maxRetries", stage.maxRetries());
            node.put("fallbackAgent", stage.fallbackAgent());
            nodes.add(node);
        }
        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("entryGate", "understand");
        result.put("exitGate", "release");
        result.put("stages", nodes);
        return result;
    }

    private void advance(final WorkflowRun run) {
        boolean progress;
        do {
            progress = false;
            if (hasTerminalStop(run)) return;

            List<WorkflowStage> ready = graph.stream()
                    .filter(stage -> run.status.get(stage.id()) == StageStatus.PENDING)
                    .filter(stage -> dependenciesSucceeded(run, stage))
                    .collect(Collectors.toList());

            for (WorkflowStage stage : ready) {
                if (stage.approvalRequired() && !run.approvals.contains(stage.id())) {
                    run.status.put(stage.id(), StageStatus.WAITING_APPROVAL);
                    audit(run, stage.id(), "GATE", "Human approval required for high-impact action");
                    progress = true;
                }
            }

            List<WorkflowStage> executable = ready.stream()
                    .filter(stage -> !stage.approvalRequired() || run.approvals.contains(stage.id()))
                    .collect(Collectors.toList());

            if (!executable.isEmpty()) {
                executable.parallelStream().forEach(stage -> execute(run, stage));
                progress = true;
            }
        } while (progress);

        if (allSuccessful(run)) {
            run.ended = Instant.now();
            audit(run, "workflow", "COMPLETE", "All entry/exit gates passed and release readiness approved");
        }
    }

    private boolean dependenciesSucceeded(WorkflowRun run, WorkflowStage stage) {
        for (String dependency : stage.dependsOn()) {
            StageStatus status = run.status.get(dependency);
            if (status != StageStatus.SUCCEEDED && status != StageStatus.FALLBACK_SUCCEEDED) return false;
        }
        return true;
    }

    private void execute(WorkflowRun run, WorkflowStage stage) {
        Map<String, Object> checkpoint = new HashMap<String, Object>(run.context);
        run.checkpoints.put(stage.id(), checkpoint);
        run.status.put(stage.id(), StageStatus.RUNNING);
        audit(run, stage.id(), "START", "Agent=" + stage.agent() + "; context checkpoint captured");

        try {
            EngineeringAgent.AgentResult result = agents.get(stage.agent()).execute(run.activeRequirement, run.context);
            if (!result.success()) throw new IllegalStateException(result.rationale());
            run.context.put(stage.id(), result.output());
            Integer previousVersion = run.artifactVersions.get(stage.id());
            run.artifactVersions.put(stage.id(), previousVersion == null ? 1 : previousVersion + 1);
            run.status.put(stage.id(), StageStatus.SUCCEEDED);
            audit(run, stage.id(), "DECISION", "Agent rationale: " + result.rationale());
            audit(run, stage.id(), "SUCCESS", "Artifact accepted into cross-stage context");
        } catch (Exception error) {
            onFailure(run, stage, error);
        }
    }

    private void onFailure(WorkflowRun run, WorkflowStage stage, Exception error) {
        if (run.firstFailureAt == null) run.firstFailureAt = Instant.now();
        Integer old = run.retries.get(stage.id());
        int attempt = old == null ? 1 : old + 1;
        run.retries.put(stage.id(), attempt);
        audit(run, stage.id(), "RETRY", "attempt=" + attempt + "; reason=" + error.getMessage());

        if (attempt <= stage.maxRetries()) {
            run.status.put(stage.id(), StageStatus.PENDING);
            return;
        }

        if (stage.fallbackAgent() != null) {
            try {
                audit(run, stage.id(), "FALLBACK_START", "Primary retry budget exhausted; invoking " + stage.fallbackAgent());
                EngineeringAgent.AgentResult fallback = agents.get(stage.fallbackAgent()).execute(stripFailureToken(run.activeRequirement, stage.agent()), run.context);
                if (fallback.success()) {
                    run.context.put(stage.id(), fallback.output());
                    Integer previousVersion = run.artifactVersions.get(stage.id());
                    run.artifactVersions.put(stage.id(), previousVersion == null ? 1 : previousVersion + 1);
                    run.status.put(stage.id(), StageStatus.FALLBACK_SUCCEEDED);
                    run.fallbackCount++;
                    run.recoveredAt = Instant.now();
                    audit(run, stage.id(), "FALLBACK_SUCCESS", fallback.rationale());
                    return;
                }
            } catch (Exception fallbackError) {
                audit(run, stage.id(), "FALLBACK_FAILED", fallbackError.getMessage());
            }
        }

        rollback(run, stage, error.getMessage());
    }

    private void rollback(WorkflowRun run, WorkflowStage stage, String reason) {
        Map<String, Object> checkpoint = run.checkpoints.get(stage.id());
        if (checkpoint != null) {
            run.context.clear();
            run.context.putAll(checkpoint);
        }
        run.rollbackCount++;
        run.recoveredAt = Instant.now();
        run.status.put(stage.id(), StageStatus.ROLLED_BACK);
        audit(run, stage.id(), "ROLLBACK", "Context restored to pre-stage checkpoint; reason=" + reason);
        audit(run, stage.id(), "SAFE_STOP", "Workflow stopped after rollback; human intervention required");
    }

    private String stripFailureToken(String requirement, String agent) {
        return requirement.replaceAll("(?i)\\[fail:" + agent + "\\]", "");
    }

    private boolean hasTerminalStop(WorkflowRun run) {
        return run.status.values().stream().anyMatch(s -> s == StageStatus.ROLLED_BACK || s == StageStatus.SAFE_STOPPED);
    }

    private boolean allSuccessful(WorkflowRun run) {
        return run.status.values().stream().allMatch(s -> s == StageStatus.SUCCEEDED || s == StageStatus.FALLBACK_SUCCEEDED);
    }

    private boolean isAmbiguous(String requirement) {
        String value = requirement.toLowerCase(Locale.ENGLISH).trim();
        return value.length() < 25
                || value.matches(".*\\b(make|improve|better|enhance)\\b.*") && !value.matches(".*\\b(api|url|latency|click|expiry|security|test|analytics)\\b.*");
    }

    private void audit(WorkflowRun run, String stage, String action, String detail) {
        run.audit.add(new AuditEvent(Instant.now(), run.id, stage, action, detail));
    }

    public Map<String, Object> metrics() {
        long total = runs.size();
        long completed = runs.values().stream().filter(r -> r.ended != null).count();
        long retries = runs.values().stream()
                .mapToLong(r -> r.retries.values().stream().mapToInt(Integer::intValue).sum()).sum();
        long rollbacks = runs.values().stream().mapToLong(r -> r.rollbackCount).sum();
        long fallbacks = runs.values().stream().mapToLong(r -> r.fallbackCount).sum();
        double latency = runs.values().stream().filter(r -> r.ended != null)
                .mapToLong(r -> Duration.between(r.started, r.ended).toMillis()).average().orElse(0.0);
        double mttr = runs.values().stream().filter(r -> r.firstFailureAt != null && r.recoveredAt != null)
                .mapToLong(r -> Duration.between(r.firstFailureAt, r.recoveredAt).toMillis()).average().orElse(0.0);

        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("runs", total);
        result.put("successRate", total == 0 ? 0.0 : (double) completed / total);
        result.put("retryCount", retries);
        result.put("fallbackCount", fallbacks);
        result.put("rollbackCount", rollbacks);
        result.put("mttrMs", mttr);
        result.put("avgEndToEndLatencyMs", latency);
        return result;
    }
}
