package com.schwab.agenticurl.domain;
import javax.persistence.*;
import java.time.Instant;
@Entity public class ShortUrl {
    @Id private String code;
    @Column(nullable=false,length=2048) private String targetUrl;
    private Instant createdAt;
    private Instant expiresAt;
    private boolean active=true;
    protected ShortUrl(){}

    public ShortUrl(String c,String u,Instant e){code=c;targetUrl=u;expiresAt=e;createdAt=Instant.now(); }

    public String getCode(){return code; }

    public String getTargetUrl(){return targetUrl; }

    public Instant getCreatedAt(){return createdAt; }

    public Instant getExpiresAt(){return expiresAt; }

    public boolean isActive(){return active; }

    public void deactivate(){active=false; } }
