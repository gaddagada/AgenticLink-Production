# AgenticLink – Production-Ready Agentic URL Shortener

AgenticLink is a Java 8 / Spring Boot 2.7 prototype built for the Agentic Proficient Software Engineer assignment. It combines a working URL-shortener service with a governed, stateful SDLC orchestration engine.

## Implemented capabilities

### URL service
- Create short URLs with optional TTL
- Redirect and record click analytics
- Deactivate links
- Validate HTTP/HTTPS targets and block local/private targets
- H2 persistence and Actuator health/metrics

### Agentic SDLC orchestration
- Explicit dependency graph with entry/exit gates
- Sequential and parallel execution (`test` and `docs` synchronize before release)
- Cross-stage context, artifact version counters and decision/audit lineage
- Human approval checkpoints for security/change-control and release
- Ambiguity detection with human clarification
- Bounded retries
- Fallback agents for implementation/testing
- Context checkpoint + rollback on unrecoverable failure
- Safe-stop after rollback
- Security/compliance/change-control guardrails
- Dynamic replanning with downstream invalidation
- Reliability metrics: success rate, retries, fallback count, rollback count, MTTR, end-to-end latency
- Executable greenfield, brownfield, ambiguous, fallback and rollback scenarios

## Requirements
- JDK 8
- Maven 3.6+

Verify:
```bash
java -version
mvn -version
```

## Build and run
```bash
mvn clean test
mvn clean package
java -jar target/agenticlink-1.0.0.jar
```

Or:
```bash
mvn spring-boot:run
```

Health check:
```bash
curl http://localhost:8080/actuator/health
```

## URL shortener demo
Create:
```bash
curl -X POST http://localhost:8080/api/urls \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com","ttlHours":24}'
```

Analytics:
```bash
curl http://localhost:8080/api/urls/{code}/analytics
```

## Orchestration demo
Start greenfield scenario:
```bash
curl -X POST http://localhost:8080/api/scenarios/greenfield
```

The response pauses at `security-review` with `WAITING_APPROVAL`. Approve it:
```bash
curl -X POST http://localhost:8080/api/orchestrations/{workflowId}/approve/security-review
```

Testing and documentation then execute as parallel-ready branches. Release pauses for final approval:
```bash
curl -X POST http://localhost:8080/api/orchestrations/{workflowId}/approve/release
```

Inspect metrics:
```bash
curl http://localhost:8080/api/orchestrations/metrics
```

Inspect dependency graph:
```bash
curl http://localhost:8080/api/orchestrations/graph
```

### Ambiguous requirement
```bash
curl -X POST http://localhost:8080/api/scenarios/ambiguous
```
It stops at `WAITING_CLARIFICATION`. Resume with:
```bash
curl -X POST http://localhost:8080/api/orchestrations/{workflowId}/clarify \
  -H "Content-Type: application/json" \
  -d '{"requirement":"Improve URL API reliability by adding expiry validation and negative tests"}'
```

### Fallback demonstration
```bash
curl -X POST http://localhost:8080/api/scenarios/fallback
```
Approve `security-review`; the deterministic test failure exhausts its retry budget and invokes the fallback testing agent.

### Rollback / safe-stop demonstration
```bash
curl -X POST http://localhost:8080/api/scenarios/rollback
```
Approve `security-review`; policy validation rejects the prohibited request, exhausts retries, restores the pre-stage context checkpoint, records a rollback, and safe-stops.

## Replanning
```bash
curl -X POST http://localhost:8080/api/orchestrations/{workflowId}/replan \
  -H "Content-Type: application/json" \
  -d '{"requirement":"Add custom aliases and expiry to the URL service"}'
```
Downstream artifacts and approvals are invalidated and regenerated under governance.

## Handover notes
See `docs/ARCHITECTURE.md`, `docs/SCENARIOS.md`, `docs/ENGINEERING_SUMMARY.md`, and `docs/HANDOVER.md`.

## Production limitation
The prototype intentionally uses deterministic local agents so it is runnable without a paid LLM/API key. The `EngineeringAgent` interface is the extension point for an LLM-backed agent. H2 is appropriate for the interview prototype; use PostgreSQL and durable workflow/event storage for a real multi-instance production deployment.
